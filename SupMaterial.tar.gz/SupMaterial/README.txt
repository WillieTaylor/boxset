All code and scripts are contained in the directory <codes>
For historical reasons, the program that runs the method is called <setsec>.
The source code (in C) is in a single file called <setsec.c> with a compile
line at the top (there is no Makefile).   It uses bits of my old C utilities
that are included in <util> along with a load of other junk (although multal
and sap are still worth using!).

A script called <boxplot.csh> runs the program and generates data for gnuplot.
The script is best run in a subdirectory as it generates lots of little fiddly
temporary files.  It looks for data files in a parent directory (called <home>)
which should include: <query.seq> (just used to pick-up the protein length),
<gremlin.dat> containing the predicted contacts (in "psicov" format) and a
file of secondary structure definitions called either <topcons.vert> (for TM,
extracted from the TOPCONS server output) or <secs.vert> for secondary structure.
These files also exist in a redundant form called <pred.dat> (used for plotting).

The TM rhodopsin example is set-up in a "play" directory called <test> and the 
other proteins are as follows...

# Transmembrane examples

# Eukaryotic rhodopsin
cd membrane/rhod/testrun
tcsh code/boxplot.csh gremlin.dat 1.0 1.0 0

# Bacterial rhodopsin
cd membrane/bact/testrun
tcsh code/boxplot.csh gremlin.dat 1.0 1.0 0

# Globular proteins

# Chemotaxis-Y protein
cd globular/cor3chyA/testrun
tcsh code/boxplot.csh gremlin.dat 1.0 5.0 1

# Some other bigger protein
cd globular/cor2opiA/testrun
tcsh code/boxplot.csh gremlin.dat 1.0 5.0 1
