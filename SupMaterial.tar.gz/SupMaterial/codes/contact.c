/*
cc -O contact.c -o contact util/wt/util.o util/wt/geom.o util/wt/sort.o -lm

./contact prot.pdb prot.cor bond ncor [S|W]

./contact FliG1-M.pdb FliG1-M.300.cor 2.0 300 S
sort -n -k4 dists.dat | head -300 > FliG1.top300.dis

*/
#include "util/wt/incl/util.h"
#include "util/wt/incl/geom.h"

#define NALLOC 1500

Vec    cas[NALLOC];
Vec    cbs[NALLOC];

main( int argc, char** argv )
{
int	i, j, k, m, n, beg, end, len, in;
char	line[225];
float	score, bond, dsum = 0.0;
FILE	*pdb, *out, *dat;
/*
int	pair[2][NALLOC];
int	maxin;
	sscanf(argv[4],"%d", &maxin);
	dat = fopen(argv[2],"r");
	in = 0;
	while (1) { int io;
		io = read_line(dat,line);
		if (io <= 0) break;
		sscanf(line,"%d %d", &i, &j);
		pair[0][in] = i; pair[1][in] = j;
		if (in==maxin) break;
		in++;
	}
	printf("%d contact pairs read\n", in);
	fclose(dat);
	sscanf(argv[3],"%f", &bond);
*/
bond = 2.0;
	Pr(bond) NL
	pdb = fopen(argv[1],"r");
	len = getca(cas,pdb);
	Pi(len) NL
	for (i=1; i<=len; i++) { Vec n,c,nc;
		vsub(cas[i],cas[i-1],&n);
		vsub(cas[i],cas[i+1],&c);
		vadd(n,c,&nc); vnorm(&nc); vmul(&nc,bond);
		vadd(cas[i],nc,cbs+i);
	}
	out = fopen("dists.dat","w");
	for (i=1; i<len; i++) { float w;
		for (j=i+1; j<=len; j++) { float dca, dcb;
			dca = vdif(cas[i],cas[j]);
			dcb = vdif(cbs[i],cbs[j]);
			fprintf(out,"%6d %6d   %6.3f   %6.3f\n", i, j, dca, dcb); 
/*
			for (k=0; k<in; k++) {
				if ((pair[0][k]==i && pair[1][k]==j) || (pair[0][k]==j && pair[1][k]==i)) {
					if ( argv[5][1]=='S' ) {
						w = (float)(j-i-1); w = sqrt(w);
					} else {
						w = (float)(j-i); w = log(w);
					}
					if ( argv[5][0]=='W' ) dcb *= w;
					dsum += dcb;
				}
			}
*/
		}
	}
	score = dsum/(float)in;
	Pr(score) NL
}

extend (res,i,j,k,new)
Vec	*res;
int	i, j, k, new;
{
	Vec	m, v;
	vave(res[j],res[k],&m);
	vsub(m,res[i],&v);
	vadd(m,v,&res[new]);
}
 
getca (res,pdb)
Vec    *res;
FILE	*pdb;
{	int	i = 1;
	char	line[225], junk[30];
        while(!feof(pdb)) {
		read_line(pdb,line);
		if (!strncmp(line,"TER",3)) break;
		if (strncmp(line,"ATOM",4)) continue;
		if (strncmp(line+13,"CA ",3)) continue;
		sscanf(line,"%30c %f%f%f", junk, &res[i].x, &res[i].y, &res[i].z);
		i++;
	}
	i--;
        extend(res,3,2,1,0);    
        extend(res,i-2,i-1,i,i+1);
	return i;
}
 
putpdb (res,out,len,sca)
Vec    *res;
FILE    *out;
int     len;
float	sca;
{       int     i = 0, n = 0;
        for (i=1; i<=len; i++) {
                	fprintf(out,"ATOM%7d  CA  GLY%6d     %7.3f %7.3f %7.3f   0.0   0.0\n",
                        i, i, sca*res[i].x, sca*res[i].y, sca*res[i].z);
        }
        fprintf(out,"TER\n");
}
