/*
cc setsec.c -o setsec util/wt/util.o -lm

*/
#include "util/wt/incl/util.h"
#include "util/wt/incl/geom.h"

float parse ( float, int );
float score ( FILE*, int, int, int, int, int );
float stripe ( float**, int, int, float[99][99], int );
float moment ( float**, int, int, int );
float momat ( int, int, float**, int, int );

int	inbox = 0;
int	len, segs;
float	**con, **mat, **sum, *emax;
int	**top[2], *edge[2], *ends[2], *base[2];
int	sec[999], set[999];

main ( int argc, char** argv )
{
float	cut = 0.0, gap = 1.0;
int	i, j, n, last, lenn, cycles = 1;//5;
FILE	*pred, *grid, *diag, *line, *boxA, *boxP, *pack, *term;
FILE	*pin = fopen("pairs.dat","r");
FILE	*sin = fopen("topcons.vert","r");
	for (i=0; i<999; i++) sec[i] = 0;
	// read TM segment consensus
	n = 0;
	len = 0;
	last = 0;
	pred = fopen("pred.dat","w");
	// count TM predictions (M) for each res in topcons (m = added helix)
	while (1) { int io; char secin[22];
		io = read_line(sin,secin);
		if (io <=0) break;
		for (i=2; i<io; i++) if (toupper(secin[i])=='M') sec[len]++;
		if (len) last = sec[len-1];
		if (sec[len]) { // in a segment
			if (last==0) { // in a new segment
				n++; last = sec[n];
			}			
		}
		set[len] = n;
		if (sec[len]) fprintf(pred,"%d %d %d\n", len+1,len+1,sec[len]);
		len++;
	}
	for (i=0; i<len; i++) if (sec[i]==0) set[i] = 0;
	if (argc>1) sscanf(argv[1],"%f", &cut);
	if (argc>2) sscanf(argv[2],"%f", &gap);
	if (cut < 0.0) { inbox = 1; cut = -cut; }
	Pi(len) Pr(cut) Pr(gap) Pi(inbox) NL
	// allocate arrays
	lenn = len+1;
	con = (float**)malloc(sizeof(float*)*lenn); TEST(con)
	mat = (float**)malloc(sizeof(float*)*lenn); TEST(mat)
	sum = (float**)malloc(sizeof(float*)*lenn); TEST(sum)
	top[0] = (int**)malloc(sizeof(int*)*lenn);  TEST(top[0])
	top[1] = (int**)malloc(sizeof(int*)*lenn);  TEST(top[1])
	for (i=0; i<lenn; i++) {
		con[i] = (float*)malloc(sizeof(float)*lenn); TEST(con[i])
		mat[i] = (float*)malloc(sizeof(float)*lenn); TEST(mat[i])
		sum[i] = (float*)malloc(sizeof(float)*lenn); TEST(sum[i])
		top[0][i] = (int*)malloc(sizeof(int)*lenn);  TEST(top[0][i])
		top[1][i] = (int*)malloc(sizeof(int)*lenn);  TEST(top[1][i])
		for (j=0; j<lenn; j++) con[i][j] = 0.0;
	}
	emax = (float*)malloc(sizeof(float)*lenn);
	edge[0] = (int*)malloc(sizeof(int)*lenn);
	edge[1] = (int*)malloc(sizeof(int)*lenn);
	ends[0] = (int*)malloc(sizeof(int)*lenn);
	ends[1] = (int*)malloc(sizeof(int)*lenn);
	base[0] = (int*)malloc(sizeof(int)*lenn);
	base[1] = (int*)malloc(sizeof(int)*lenn);
	// read predicted contacts
	n = 0;
	while (1) { int io, a,b,c,d; float x,e; char conin[22];
		io = read_line(pin,conin);
		if (io <=0) break;
		sscanf(conin,"%d %d %d %d %f", &a,&b,&c,&d,&e);
		if (a>len || b>len) continue;
		a--; b--; // pairs read in range 1..N
		// NB values accumulate and 1/2 weight for reverse indices
		// x = (float)n;
		// e = exp(-x*x*0.01/(float)len); // so all souces score same
		if (a>b) e *= 0.5;
		con[a][b] += e;
		con[b][a] += e; 
		n++;
	}
	Pi(n) NL
/* print contact matrix
for(i=0; i<len; i++) { for (j=0; j<len; j++) {
	if (i==j) printf("%3d",set[i]); else printf("%3d",(int)(100.0*con[i][j]));
}  NL } NL
*/
	for (i=0; i<cycles; i++) { float s;
		s = parse(gap,i);
		Pi(i) Pr(s) NL
	}
	NLL
	for (i=0; i<lenn; i++) for (j=0; j<lenn; j++) mat[i][j] = sum[i][j] = 0.0;
	term = fopen("ends.dat","w");
	pack = fopen("pack.dat","w");
	grid = fopen("grid.plot","w");
	boxA = fopen("boxA.plot","w");
	boxP = fopen("boxP.plot","w");
	for (i=0; i<segs; i++)
	{	int m, w, ai,bi, aj,bj, zero=0;
		ai = ends[0][i]; bi = ends[1][i];
		w = (bi-ai)/2;
		m = ai+w-1;
		fprintf(term,"%5d %5d\n", ai,bi);
		printf("\t%d-%d\t",ai,bi); Pi(m) Pi(w) NL
		fprintf(grid,"%4d %4d\n",  zero,ai);
		fprintf(grid,"%4d %4d\n\n", len,ai);
		fprintf(grid,"%4d %4d\n",  zero,bi);
		fprintf(grid,"%4d %4d\n\n", len,bi);
		fprintf(grid,"%4d %4d\n",  ai,zero);
		fprintf(grid,"%4d %4d\n\n", ai,len);
		fprintf(grid,"%4d %4d\n",  bi,zero);
		fprintf(grid,"%4d %4d\n\n", bi,len);
		for (j=0; j<segs; j++) // score each box
		{ float s; int a,b; FILE *box;
			if (i <= j) continue;
			aj = ends[0][j]; bj = ends[1][j];
			s = score(pack,m,w,i,j,-1);
			if (s < 0.0) { s = -s; box = boxP; } else { box = boxA; }
			if (s < cut) continue;
			fprintf(box,"%4d %4d %f\n",  ai,aj,s);
			fprintf(box,"%4d %4d\n",  ai,bj);
			fprintf(box,"%4d %4d\n",  bi,bj);
			fprintf(box,"%4d %4d\n",  bi,aj);
			fprintf(box,"%4d %4d\n\n",ai,aj);
			fprintf(box,"%4d %4d\n",  aj,ai);
			fprintf(box,"%4d %4d\n",  aj,bi);
			fprintf(box,"%4d %4d\n",  bj,bi);
			fprintf(box,"%4d %4d\n",  bj,ai);
			fprintf(box,"%4d %4d\n\n",aj,ai);
			for (a=ai; a<=bi; a++) for (b=aj; b<=bj; b++) sum[a][b] = mat[a][b];
		}
	}
	diag = fopen("diag.plot","w");
	line = fopen("line.dat","w");
	for (i=0; i<lenn; i++) { for (j=0; j<lenn; j++) {
		if (sum[i][j] < 0.0) { int sup; float s = -sum[i][j];
			// separate score and mark 
			sup = (int)(s/1000.0);
			s -= 1000.0*(float)sup;
			fprintf(line,"%5d %5d %7.1f\n", i,j,s);
			sum[i][j] = (s-sum[i][j])/1000.0-0.2;
		}
		if (sum[i][j] > 0.01) {
			if (i>j) fprintf(diag,"%5d %5d\n", i,j);
			if (j>i) fprintf(diag,"%5d %5d\n", i,j);
		}
	} }
}

float parse ( float gap, int cycle )
{
int	maxseg = 50;
int	minseg = 4;
int	i, j, n;
int	m, w, topm, topw;
float	tops;
	for (m=0; m<len; m++) for (w=0; w<len; w++) mat[m][w] = sum[m][w] = 0.0;
	// fill mat with the raw scores
	for (m=2; m<len-2; m++) { int skip; float d, e; // m = 5..len-5 allows w=5 at each end (min seg = 11)
		for (w=2; w<maxseg/2; w++) { float s;
			if (m-w < 0) break;
			if (m+w > len-1) break;
			//mat[m][w] = -gap*(float)(w+1);
			if (w>minseg) mat[m][w] = -gap*sqrt((float)(w-minseg));
			mat[m][w] += score(0,m,w,0,0,cycle);
		}
	}
	for (m=0; m<len; m++) {
		if (set[m]) printf("%3d | %1d", m+1,set[m]); else printf("%3d |  ", m+1);
		sum[m][0] = mat[m][0] = 0.0;
		sum[m][1] = mat[m][1] = 0.0;
		for (w=1; w<20; w++) printf("%3d", (int)(mat[m][w])); NL
	}
	// fill sum with the accummulated scores
	for (w=2; w<maxseg/2; w++) {
		//WAS  for (m=2; m<len-2; m++) {
		for (m=2; m<len-2; m++) {
			if (m-w < 0) continue;
			if (m+w > len-1) continue;
			if (w==2 && sum[m][1] > 0.0) {
					sum[m][w] = mat[m][w]+sum[m][1]+sum[m-1][1]+sum[m+1][1];
			} else {
					sum[m][w] = sum[m-1][w-1]+sum[m+1][w-1]-sum[m][w-2]+mat[m][w]+mat[m][w-1];
			}
		}
	}
	NLL
	for (m=0; m<len; m++) {
		if (set[m]) printf("%3d | %1d", m+1,set[m]); else printf("%3d |  ", m+1);
		for (w=1; w<20; w++) {
			if (set[m-w] != set[m+w]) sum[m][w] = -1.0;
			if (set[m-w]==0 || set[m+w]==0) sum[m][w] = -1.0;
			if (sum[m][w] > 0.0) printf("%4d", (int)sum[m][w]);
					else printf("    ");
		} NL
	}
	for (m=0; m<=len; m++) {
		emax[m] = 0.0;
		edge[0][m] = edge[1][m] = 0;
		for (w=0; w<len; w++) {
			top[0][m][w] = top[1][m][w] = -1;
			if (inbox==0) continue;
			// wipe out scores not inside a segment (set[]>0)
			if (set[m-w] != set[m+w]) sum[m][w] = -1.0;
			if (set[m-w]==0 || set[m+w]==0) sum[m][w] = -1.0;
		}
	}
	// seq runs 0..N-1
	tops = 0.0;
	for (n=3; n<len; n++) {
		m = n+1;
		for (w=1; w<maxseg/2; w++)
		{ float max;
		  int	p, q, r;
			m--;	// move back centre as window gets bigger
			if (m-w < 0) break;
			if (m+w > len) break;
			max = 0.0;
			r = i = m-w-3; /* -3 forces 2 gaps  between segments */
			// r = i = m-w-2; /* -2 forces one gap between segments */
			if (r < 0) continue;
			p = q = j = 0;
			while (i>0 && j<len/2) {
				/* scan leading edge for max */
				if (sum[i][j] > max) {
					if (j>minseg) {
						max = sum[i][j];
						p = i; q = j;
					}
				}
				i--; j++;
			}
			// for each diagonal (r) hold max and its position
			emax[r] = max;
			edge[0][r] = p;
			edge[1][r] = q;
			max += sum[m][w];	// score = current (m,w) + last diag max
			for (i=1; i<=r; i++)	// then scan earlier edges for better max
			{ float s = sum[m][w]+emax[i];
				if (s > max) {
					max = s;
					p = edge[0][i];
					q = edge[1][i];
				}
			}
			top[0][m][w] = p;
			top[1][m][w] = q;
                        sum[m][w] = max;	// overwrite sum to hold max
                        if (sum[m][w] > tops) {
                                tops = sum[m][w];
                                topm = m; topw = w;
                        }
		}
	}
	n = 0;
	NLL // Pr(tops) NLL
	i = topm; j = topw;
	while (i>0 && j>0) { int ii, jj;
		Pi(i) Pi(j) Pr(sum[i][j]) NL
		edge[0][n] = i;
		edge[1][n] = j;
		ii = top[0][i][j]; jj = top[1][i][j];
		i = ii; j = jj;
		n++;
	}
	NL
	if (cycle==0) for (i=0; i<len; i++) set[i] = 0; // reset <set> to starting segments
	segs = 0;
	for (i=n-1; i>-1; i--)
	{ int	nn = edge[0][i]-edge[1][i]+1,
		cc = edge[0][i]+edge[1][i]+1;
		j = n-1-i;
		segs++;
		ends[0][j] = nn;
		ends[1][j] = cc;
		if (cycle>0) continue;
		base[0][j] = nn;
		base[1][j] = cc;
		for (j=nn; j<=cc; j++) set[j-1] = segs;
	}
	for (i=0; i<segs; i++) {
		printf("   %d-%d",ends[0][i],ends[1][i]);
	}
	Pr(tops) NL
	return tops;
}

float score ( FILE *out, int m, int w, int si, int sj, int cycle ) {
float	dia[99][99], dip[99][99]; // holds best diagonals in stripe()
float	tmpred = 0.0;
float	consum = 0.0;
float	boxsum, pack, pars, ants;
float	**box, **xob; 
int	a,b, seg1,seg2;
int	i, j, k, n = 0;
int	am = m-w, pm = m+w;
int	print = 0;
int	one = 0;
int	id = 0;
	box = (float**)alloca(sizeof(float*)*99);
	xob = (float**)alloca(sizeof(float*)*99);
	for (i=am; i<=pm; i++) { // sum TM prediction for the segment
		if (set[i]) {	   // in a segment
			if (id==0) { // hold the first seg ID
				id = set[i];
			} else {
				if (set[i] != id) return -1.0; // two segs in one window
			}
		}
		tmpred += sqrt((float)sec[i]);
		n++;
	}
	tmpred /= (float)n;
//	if (cycle==0) return tmpred*2.0; // first pass is just TM prediction score
	a = w+w+1; // current seg length
//	if (a < 15) return tmpred;
//	if (a > 55) return tmpred;
	if (print) { Pi(m) Pi(w) Pi(am) Pi(pm) NL }
	if (cycle < 0) {	// -ve = flag for one box run (segIDs = si,sj)
		one = 100*si+sj; 	// unique id for later sort
		seg1 = sj; seg2 = seg1+1;
	} else {	// default = run over all segs (bar self) 
		seg1 = 0; seg2 = segs;
	}
	for (k=seg1; k<seg2; k++) // for each segment (NB ends = 1..N)
	{ int	ak = ends[0][k]-1, pk = ends[1][k]-1, ss = 0;
	  float bias;
		if ((ak>=am && ak<=pm) || (pk<=pm && pk>=am)) continue;
		b = pk-ak+1;
		boxsum = 0.0;
		for (j=ak; j<=pk; j++) { // sum pairs in box (not self)
			for (i=am; i<=pm; i++) {
				boxsum += con[j][i];
				if (sec[i] && sec[j]) ss++;
			}
		}
		if (print) { SPP SPP Pi(k) Pi(ak) Pi(pk) Pi(a) Pi(b) Pr(boxsum) Pi(ss) NL }
		if (boxsum < 1.0) continue; // too weak to score
		if (ss==0) continue;	// no pverlapping helix prediction
		if (a>b) {
			for (j=0; j<a; j++) box[j] = xob[a-j-1] = con[j+am]+ak;
			if (print) { for (i=0;i<a;i++){ for(j=0;j<b;j++) printf("%3d",(int)(box[i][j]*100.0)); NL} NL }
			bias = moment(box,a,b,one);	// bias<0 = anti
			if (one) { // copy the diagonal scores into the full plot
				if (bias>0.0) {
					pack = stripe(box,a,b,dip,one);
					for (i=0; i<a; i++) for(j=0; j<b; j++) mat[i+am+1][j+ak+1] = dip[i][j];
				} else {
					pack = stripe(xob,a,b,dia,one);
					for (i=0; i<a; i++) for(j=0; j<b; j++) mat[i+am+1][j+ak+1] = dia[a-i-1][j];
				}
			}
		} else {
			for (j=0; j<b; j++) box[j] = xob[b-j-1] = con[j+ak]+am;
			if (print) { for (i=0;i<b;i++){ for(j=0;j<a;j++) printf("%3d",(int)(box[i][j]*100.0)); NL} NL }
			bias = moment(box,b,a,one);
			if (one) { // copy the diagonal scores into the full plot
				if (bias>0.0) {
					pack = stripe(box,b,a,dip,one);
					for (i=0; i<b; i++) for(j=0; j<a; j++) mat[j+am+1][i+ak+1] = dip[i][j];
				} else {
					pack = stripe(xob,b,a,dia,one);
					for (i=0; i<b; i++) for(j=0; j<a; j++) mat[j+am+1][i+ak+1] = dia[b-i-1][j];
				}
			}
		}
		if (print) { SPP SPP Pr(pack) NLL }
		if (one) { char pa; // score for single box (-/+ = ant/par)
			if (bias<0.0) pa = 'A'; else pa = 'P';
			fprintf(out,"%5d %5d   %f %f %f  %c %f\n", si+1,sj+1, boxsum,ants,pars,pa,bias,pack);
			if (bias<0.0) pack = -pack;
			return boxsum*pack;
		}
		consum += 0.1*boxsum*pack;
	}
	if (one) return 0.0;
	if (print) { Pr(consum) NL }
	if (consum<0.1) return tmpred*2.0;
	return tmpred+consum;
}

float moment ( float **box, int a, int b, int seg )
// calculate the inertial moment ratio for the points in the box
{
int	i,j;
float	score, sum;
float	midX, midY, cenX,cenY, momh,momg; // centroid and moments about each diagonal
	cenX = cenY = sum = 0.0;
	midX = 0.5*(float)a; midY = 0.5*(float)b;
	//for (i=0; i<a; i++) { for (j=0; j<b; j++) printf("%3d",(int)(100.0*box[i][j])); NL }
	for (i=0; i<a; i++) {
		for (j=0; j<b; j++)
		{ float x,y, dd,g, w = box[i][j];
			if (w < NOISE) continue;
			x = (float)i-midX; y = (float)j-midY;
			dd = x*x+y*y;	// sq.d to crntre of box
			g = exp(-dd*0.01);
			cenX += g*w*(float)i;
			cenY += g*w*(float)j;
			sum += g*w;	// centre weighted sum
		}
	}
	cenX /= sum; cenY /= sum;	// weighted centroid of box
	sum = momh = momg = 0.0;      
	for (i=0; i<a; i++) {
		for (j=0; j<b; j++)
		{ float x,y, dd,hh,gg,xx,yy, w = box[i][j];
			if (w < NOISE) continue;
			x = (float)i-cenX; xx = x*x;
			y = (float)j-cenY; yy = y*y;
			dd = xx+yy;
			hh = dd*0.5 - x*y;
			gg = dd*0.5 + x*y;
			momh += hh*w;
			momg += gg*w;
			sum += w;
		}
	}
	momh = sqrt(momh/sum)+1.0;
	momg = sqrt(momg/sum)+1.0;
	if (momh > momg) {
		score = -momh/momg +1.0;
	} else {
		score =  momg/momh -1.0;
	}
	return score;
}

float stripe ( float **box, int a, int b, float dig[99][99], int seg )
// score the diagonal stripe for each full diagonal (NB: a>b)
// NB: <box> points into <con> so a change to <box> -> change to <con>
{
float	maxt = -999.9;
int	i,j, maxi,maxj;
int	iup,jup, idn,jdn;
int	e1i,e1j, e2i,e2j;
int	mida=a/2, midb=b/2;
Pi(a) Pi(b) Pi(mida) Pi(midb) NL
	iup = idn = mida; jup = jdn = midb;
	while (1) { float t;	// for each full diagonal
		t = momat(iup,jup,box,a,b);
		if (t>maxt) { maxt=t; maxi=iup; maxj=jup; }
		iup++;
		t = momat(iup,jup,box,a,b);
		if (t>maxt) { maxt=t; maxi=iup; maxj=jup; }
		jup--;
		if (jdn-idn >= b/2) break; 
		idn--;
		t = momat(idn,jdn,box,a,b);
		if (t>maxt) { maxt=t; maxi=idn; maxj=jdn; }
		jdn++;
		t = momat(idn,jdn,box,a,b);
		if (t>maxt) { maxt=t; maxi=idn; maxj=jdn; }
	}
	Pr(maxt) Pi(maxi) Pi(maxj) NL
	if (seg>0) { float mark = (float)(-seg); // seg = sort key for lines
		for (i=0; i<a; i++) for (j=0; j<b; j++) dig[i][j] = 0.0;
/*
		for (i=0; i<b; i++) { // mark best diag
			if (i+maxk > b) break;
			if (i+maxk < 0) continue;
			//dig[i+maxk][i] = 1.0; // mark best diag
		}
*/
		// run max point out to an edge
//i=maxi; maxi=maxj; maxj=i;
		a--; b--;
		e1i = maxi; e1j = maxj;
		while (1) { e1i--; e1j--; if (e1i==0 || e1j==0) break; } 
		e2i = maxi; e2j = maxj;
		while (1) { e2i++; e2j++; if (e2i==a || e2j==b) break; } 
Pi(e1i) Pi(e1j) Pi(e2i) Pi(e2j) NL
		// protect value then add mark at line endpoints
		if (dig[e1i][e1j] > 1.0) dig[e1i][e1j] = -1000.0*(float)((int)dig[e1i][e1j]);
		if (dig[e2i][e2j] > 1.0) dig[e2i][e2j] = -1000.0*(float)((int)dig[e2i][e2j]);
		dig[e1i][e1j] += mark-0.1; dig[e2i][e2j] += mark-0.2; // 0.1-0.2 used to sort ends
	}
	return maxt;
}

float momat ( int p, int q, float **box, int a, int b )
// calculate the inertial moment points in the box about p,q
{
int	i,j;
float	mom = 0.0, sum = 0.0; // centroid and moments about each diagonal
	for (i=0; i<a; i++) {
		for (j=0; j<b; j++)
		{ float x,y, dd,hh,g,xx,yy, w = box[i][j];
			if (w < NOISE) continue;
			x = (float)(i-p); xx = x*x;
			y = (float)(j-q); yy = y*y;
			dd = xx+yy;
			hh = dd*0.5 + x*y;
			g = exp(-hh*0.01);
g=1.0;
			mom += g*w*hh;
			sum += g*w;
		}
	}
	mom = sqrt(mom/sum)+1.0;
	return mom;
}

float oldstripe ( float **box, int a, int b, float dig[99][99], int seg )
// score the diagonal stripe for each full diagonal (NB: a>b)
// NB: <box> points into <con> so a change to <box> -> change to <con>
{
int	n, m = 10;
float	width = 4.0, ww = width*width;
float	diag[99], best[99];
float	r,s,t, maxt = -999.9;
int	i,j,k, maxk = -1;
float	mid, mom, sum; // pivot and spread along the diagonal
	for (k=0; k<=a-b; k++) { // for each full diagonal
		if (seg>0) for (i=0; i<b; i++) diag[i] = 0.0;
		t = 0.0; n = 0;
		for (i=0; i<b; i++) { // along the diagonal 
			s = 0;
			for (j=i-m; j<i+m; j++) { // sum for each row
				if (j<0 || j>=b) continue;
				r = (float)(i-j);
				r = exp(-r*r/ww);
				s += r*box[i+k][j];
			}
			for (j=i-m; j<i+m; j++) { // sum for each col
				if (j+k<0 || j+k>=a) continue;
				r = (float)(i-j);
				r = exp(-r*r/ww);
				s += r*box[j+k][i];
			}
			diag[i] = s;
			t += s;
			n++;
		}
		// find the diagonal pivot point
		sum = 0.0;
		for (i=0; i<b; i++)  sum += diag[i];
		mid = 0.0;
		for (i=0; i<b; i++)  mid += diag[i]*(float)i;
		mid /= sum;
		// find the diagonal moment of inertia
		mom = 0.0;
		for (i=0; i<b; i++)
		{ float d = (float)i - mid;
			mom += d*d*diag[i];
		}
		mom /= sum;
		t = t*10.0 + sqrt(mom);
		if (t > maxt) { // hold the best diagonal sum
			maxk = k; maxt = t;
			for (i=0; i<b; i++) best[i] = diag[i];
		}
	}
	if (seg>0) { float mark = (float)(-seg);
		for (i=0; i<a; i++) for (j=0; j<b; j++) dig[i][j] = 0.0;
		for (i=0; i<b; i++) dig[i+maxk][i] = best[i]*10.0; // mark best diag
		// protect value then add mark
		if (dig[maxk+b-1][b-1] > 1.0) dig[maxk+b-1][b-1] = -1000.0*(float)((int)dig[maxk+b-1][b-1]);
		if (dig[maxk][0] > 1.0) dig[maxk][0] = -1000.0*(float)((int)dig[maxk][0]);
		dig[maxk][0] += mark-0.1; dig[maxk+b-1][b-1] += mark-0.2; 
	}
	return maxt;
}
