/*
cc -ggdb select.c -o select ~/util/wt/util.o ~/util/wt/sort.o ~/util/wt/geom.o -lm

*/
#include "code/util.h"
#include "code/geom.h"
#include <math.h>

#define NRES 1000
#define NSEQS 5000
#define NACID 27
#define GAP '-'
#define LOW 10.0
#define TOP 100.0
#define KEEP 2
#define FEW 3
#define GAPEN 1

typedef struct	{
		short	a, b;
		float	score;
		char	type;
		}
	Pairs;

typedef	struct	{
		short	alfa,
			beta,
			coil;
		}
	Pred;

typedef	struct	{
		Vec	alpha, beta;
		char	info[35], res;
		float	occu, bval, phob, size, cons, pred;
		Pred	predict;
		}
	Atom;
Atom	atom[NRES];

typedef	struct	{
		char	*residue,
			title[500],
			code[40];
		short	id,
			length;
		Pred	*predict;
		}
	Seqs;
int	length, mat_wt = 0,
	id_mat[NACID][NACID],
	md_mat[NACID][NACID];
float	phobic[NACID];
char	idac[NACID];
char	amino3[80], aaa[4];
int	nacid, nprots, xray = 0; // default is first sequence
FILE	*aln, *lis;
FILE	*segs, *tops;
int	seg[999], top[999];

main()
{
Seqs	sequence[NSEQS];
char	xcode[20], line[222];
float	pred[NRES], vari[NRES], phob[NRES], cone[NRES], dssp[NRES];
float	cut = 2.0;
int	i, len, slen, xlen, nseq;
	strcpy(amino3,
	"ALAASXCYSASPGLUPHEGLYHISILEACELYSLEUMETASNPCAPROGLNARGSERTHRUNKVALTRPXXXTYRGLX"
	);
	matin("data/id.mat",id_mat);
	matin("data/md.mat",md_mat);
	aln = fopen("final.aln","r");
	lis = fopen("select.lis","w");
	nseq = filter(sequence,xcode);
	phobin("data/phobic.dat");
	len = slen = profile(sequence,nseq,vari,phob);
/*
	xlen = access(xcode,cone,dssp);
	if (slen != xlen) { printf("*NB* length diff!\n"); exit(1); }
		else len = length = xlen;
	for (i=0; i<length; i++) dssp[i] = -dssp[i];
*/
	for (i=0; i<length; i++) dssp[i] = cone[i] = 0.0;

	printf("Normalise phob data\n");
	norm(cut,phob,len);
	while (norm(cut,phob,len));
	norm(cut,phob,len);

	printf("Normalise vari data\n");
	norm(cut,vari,len);
	while (norm(cut,vari,len));
	norm(cut,vari,len);
/*
	printf("Normalise cone data\n");
	norm(cut,cone,len);
	while (norm(cut,cone,len));
	norm(cut,cone,len);

	printf("Normalise dssp data\n");
	norm(cut,dssp,len);
	while (norm(cut,dssp,len));
	norm(cut,dssp,len);
*/
	predict(pred,vari,phob,len);
	plotfiles(pred,vari,phob,len);
	for (i=0; i<999; i++) top[i] = seg[i] = 0;
	tops = fopen("pred.dat","r");
	while (1) { int a,b,c, in = read_line(tops,line);
		if (in <= 0) break;
		sscanf(line,"%d %d %d", &a,&b,&c);
		top[a] = c;
	}
	segs = fopen("ends.dat","r");
	while (1) { int a,b, in = read_line(segs,line);
		if (in <= 0) break;
		sscanf(line,"%d %d", &a,&b);
		for (i=a; i<=b; i++) seg[i] = 1;
	}
	combine(sequence,nseq,pred,vari,phob,dssp,cone);
}

predict (pred, vari, phob, len)
float   *pred, *vari, *phob;
int     len;
{
int     i;
float	base = 2.0;
	for (i=0; i<len; i++)
	{ float v = vari[i]+base,
		p = phob[i]+base;
		v = exp(-v*v*0.5);
		p = 1.0 - exp(-p*p*0.5);
		pred[i] = 10.0*p*v;
	}
}
 
autocor (c, d, n)
float	*c, *d;
int	n;
{
float	corr, sync, csum, cmax;
int	i, j, k;
	for (i=0; i<n; i++) {
		cmax = corr = 0.0;
		for (j=0; j<n; j++) {
			k = i+j;
			if (k>=n) k -= n;
			corr += c[j]*d[k];
		}
		corr /= (float)n;
		if (i) { 
			csum += corr*corr;
			if (corr>cmax) cmax = corr;
		} else { sync = corr; }
	}
	csum /= (float)(n-1);
	csum = sqrt(csum);
	printf("corr = %7.3f, back = %7.3f, cmax = %7.3f, spec = %7.3f\n",
		sync, csum, cmax, sync/cmax);
}

plotfiles (pred, cone, dssp, len)
float	*pred, *cone, *dssp;
int	len;
{
int	i;
FILE	*out;
	out = fopen("predseq.dat","w");
	for (i=0; i<len; i++) fprintf(out,"%7d %7.3f\n", i+1,pred[i]);
	fclose(out);
	out = fopen("variseq.dat","w");
	for (i=0; i<len; i++) fprintf(out,"%7d %7.3f\n", i+1,cone[i]);
	fclose(out);
	out = fopen("phobseq.dat","w");
	for (i=0; i<len; i++) fprintf(out,"%7d %7.3f\n", i+1,dssp[i]);
	fclose(out);
	out = fopen("predvari.dat","w");
	for (i=0; i<len; i++) fprintf(out,"%7.3f %7.3f\n", pred[i],cone[i]);
	fclose(out);
	out = fopen("predphob.dat","w");
	for (i=0; i<len; i++) fprintf(out,"%7.3f %7.3f\n", pred[i],dssp[i]);
	fclose(out);
	out = fopen("variphob.dat","w");
	for (i=0; i<len; i++) fprintf(out,"%7.3f %7.3f\n", cone[i],dssp[i]);
	fclose(out);
}

filter (sequence,xcode,pred)
char	*xcode;
float	*pred;
Seqs	*sequence;
{
int	members, natoms, left, i, j, k;
float	**sim;
	members = read_aln(sequence,xcode);
	if (!members) return 0;
	if (members<FEW) {
		printf("Too few members\n\n");
		return 1;
	}
	if (xray<0) {
		printf("No X-ray sequence specified --- first taken\n\n");
		xray = 0;
	}
	j = members+1;
	sim = (float**)malloc(sizeof(float*)*j);
	for (i=0; i<j; i++) sim[i] = (float*)malloc(sizeof(float)*j);
	simat(sim,sequence,members);
	left = members;
	/*
	printf("Eliminating low pairs\n");
	while (lowout(sim,sequence,members,&left));
	printf("%d sequences left\n\n", left);
	*/
	printf("Eliminating high pairs\n");
	while (exclude(sim,sequence,members,&left));
	printf("%d sequences left\n\n", left);
	if (left<FEW) { printf("Too few members left\n\n"); exit(1); }
	return output(sim,sequence,members,left,pred);
}

matin(file,mat)
	char	*file;
	int	mat[NACID][NACID];
{
	int	i, j, mat_const;
	char	acid[NACID], c;
	FILE	*mat_file;

	mat_file = fopen(file,"r");
	while( c = getc(mat_file), c != '\n' ) putchar(c); NL
	fscanf(mat_file,"%s\n",acid);
	printf("%s\n",acid);
	fscanf(mat_file,"%d\n",&mat_const);
	printf("matrix constant = %d\n",mat_const);
	for( i = 0; acid[i]; i++ ) 
	{	int	ai = acid[i]-'A';
		for( j = 0; acid[j]; j++ ) 
		{	int aj = acid[j]-'A';
			fscanf(mat_file,"%d",&mat[ai][aj]);
			mat[ai][aj] += mat_const;
		}
	}
}

getpdb (file)
char	*file;
{	FILE	*pdb;
	int	natoms,
		i=0, j=0, n=0;
	float	occu, bval, bsum = 0.0, fn;
	char	filename[100];
	strcpy(filename,"/home/pdb/brk/");
	strncpy(file+4,".pdb",4);
	pdb = fopen(file,"r");
	if (!pdb) {
		strcat(filename,file);
		pdb = fopen(filename,"r");
		if (!pdb) {
			printf("*NB* pdb file not found\n");
			PRINTs(filename) NL
			exit(1);
		}
		printf("Opening pdb file %s\n", filename);
	} else  printf("Opening pdb file %s\n", file);
	while (!feof(pdb)) {
		fscanf(pdb,"%30c %f %f %f %f %f",
			 atom[n].info,
			&atom[n].alpha.x,
			&atom[n].alpha.y,
			&atom[n].alpha.z,
			&occu, &bval);
		next_line(pdb);
		if (!strncmp(atom[n].info,"TER",3)) break;
		if (strncmp(atom[n].info,"ATOM",4)) continue;
		if (!strncmp(atom[n].info+12," N  ",4)) {
			if (n) atom[n-1].bval = bsum/(float)i;
			bsum = bval;
			i = 0;
		}	
		bsum = bsum + bval;
		i++;
		if (!strncmp(atom[n].info+12," CA ",4)) {
			vcopy(atom[n].alpha,&atom[n].beta);
			atom[n].occu = bval;
			n++;
		}
		if (!strncmp(atom[n].info+12," CB ",4)) {
			vcopy(atom[n].alpha,&atom[n-1].beta);
		}
	}
	if (i) atom[n-1].bval = bsum/(float)i;
	natoms = n - 1;
	printf("%d atoms\n", natoms);
	return natoms;
}

read_aln(seq,xcode)
Seqs	*seq;
char	*xcode;
{
int	i, j, n, members, xmax;
	next_line(aln);
	fscanf(aln,"%d",&members);
	next_line(aln);
	printf("%d members in alignment\n", members);
	xray = xmax = -1;
	for (i=0; i<members; i++)
	{	Seqs	*s = seq+i;
		s->residue = (char*)malloc(sizeof(char)*(NRES+1));
		TEST(s->residue)
		s->id = i+1;
		fscanf(aln,"%s",s->code);
		read_line(aln,s->title);
		printf("%d %s %s\n",s->id,s->code,s->title);
		if (s->code[0]=='X') {
			xray = i; xmax = 999;
			strcpy(xcode,s->code+1);
		}
		if (isdigit(s->code[3]))
		{ int	xnum = (int)s->code[3]-'0';
			if (xnum>xmax) {
				xray = i;
				xmax = xnum;
			}
		}
	}
	if (xray) printf("Sequence %d = X-ray\n", xray+1);
		
	n = 0;
	while (!feof(aln)) 
	{ char	line[NSEQS+1], xres;
	  int	nchar = read_line(aln,line);
		if (nchar<members) {
			length = n-1;
			printf("alignment length = %d\n",length);
			return members;
		}
		for ( i=0; i<members; i++)
		{	Seqs	*s = seq+i;
			s->residue[n] = line[i];
			if (s->residue[n] < ' ') { n--; break; }
			if ( n>NRES ) {
				printf("*NB* alignment too long\n");
				n = NRES;
				break;
			}
		}
		if (n==NRES) break;
		n++;
	}
	return 0;
}

simat (sim,seq,memb)
float	**sim;
Seqs	*seq;
int	memb;
{
	float	fm = (float)memb,
		fl = (float)length,
		minsim, maxsim;
	int	i, j, m, n, sum, sumall;
	for (i=0; i<(memb-1); i++) {
		for (j=i+1; j<memb; j++) {
			sum = n = 0;
			for (m=0; m<length; m++) 
			{ char	a = (seq+i)->residue[m];
	  		  int	ia = UPPER(a)-'A';
			  char	b = (seq+j)->residue[m];
	  	  	  int	ib = UPPER(b)-'A',
				matab = id_mat[ia][ib];
				if (a==GAP || b==GAP) continue;
				sum += matab;
				sumall += matab;
				n++;
			}
			sim[i][j] = sim[j][i] = 10.0*(float)sum/(float)n;
		}
	}
	NL
	maxsim = 0.0;
	minsim = 9999.9;
	for (i=0; i<(memb-1); i++) {
		for (j=1; j<memb; j++)
		{ float sij = sim[i][j];
			if (j<=i) {
				printf("     ");
				continue;
			}
			printf("%5.1f", sij);
			if (sij<minsim) minsim = sij;
			if (sij>maxsim) maxsim = sij;
		} NL
	} NL
	printf("Similarity range %5.1f ---> %5.1f\n\n", minsim,maxsim);
}

lowout (sim,seq,memb,left)
float	**sim;
Seqs	*seq;
int	memb, *left;
{
	float	minsim, maxsim;
	int	i, j, mini, minj, out;
	minsim = 999.9;
	for (i=0; i<(memb-1); i++) {
		if (seq[i].id<0) continue;
		for (j=i+1; j<memb; j++) {
			if (seq[j].id<0) continue;
			if (sim[i][j]<minsim) {
				minsim = sim[i][j];
				mini = seq[i].id-1;
				minj = seq[j].id-1;
			}
		}
	}
	if (minsim>LOW) return 0;
	out = -1;
	if (mini==xray)  out = minj;
	if (minj==xray)  out = mini;
	if (out<0 && sim[xray][mini]<LOW) out = mini;
	if (out<0 && sim[xray][minj]<LOW) out = minj;
	if (out<0) {
		if (sim[xray][mini] > sim[xray][minj])
			out = mini;
		else 	out = minj;
	}
	seq[out].id = -1;
	/* printf("Sequence %d out\n", out); */
	(*left)--;
	return 1;
}

exclude (sim,seq,memb,left)
float	**sim;
Seqs	*seq;
int	memb, *left;
{
	float	minsim, maxsim;
	int	i, j, maxi, maxj, out;
	maxsim = 0.0;
	for (i=0; i<(memb-1); i++) {
		if (seq[i].id<0) continue;
		for (j=i+1; j<memb; j++) {
			if (seq[j].id<0) continue;
			if (sim[i][j]>maxsim) {
				maxsim = sim[i][j];
				maxi = seq[i].id-1;
				maxj = seq[j].id-1;
			}
		}
	}
	out = -1;
	if (maxi==xray)  out = maxj;
	if (maxj==xray)  out = maxi;
	if (out<0) {
		if (sim[xray][maxi] > sim[xray][maxj])
			out = maxi;
		else 	out = maxj;
	}
	if (maxsim < TOP) return 0;
	if (*left < KEEP) return 0;
	seq[out].id = -1;
	(*left)--;
	return 1;
}

output (sim,seq,memb,left)
float	**sim;
Seqs	*seq;
int	memb, left;
{
	float	minsim, maxsim;
	int	i, j, k, n, nseq;
	FILE	*out, *mul;
	maxsim = 0.0;
	minsim = 9999.9;
	for (i=0; i<(memb-1); i++) {
		if (seq[i].id < 0) continue;
		for (j=1; j<memb; j++)
		{ float sij = sim[i][j];
			if (seq[j].id < 0) continue;
			if (j<=i) {
				printf("     ");
				continue;
			}
			printf("%5.1f", sij);
			if (sij<minsim) minsim = sij;
			if (sij>maxsim) maxsim = sij;
		} NL
	} NL
	printf("Final similarity range %5.1f ---> %5.1f\n\n", minsim,maxsim);
	mul = fopen("select.seq","w");
	nseq = n = 0;
	for (j=0; j<memb; j++)
	{ Seqs	*s = seq+j;
		if (s->id < 0) continue;
		fprintf(mul,"%s %s\n",s->code,s->title);
		seq[nseq].id = s->id;
		strcpy(seq[nseq].code,s->code);
		strcpy(seq[nseq].title,s->title);
		n = 1;
		for (i=0; i<length; i++) {
			seq[nseq].residue[i] = s->residue[i];
			if (s->residue[i]=='-') continue;
			fprintf(mul,"%c", s->residue[i]);
			if (!(n-80*(n/80))) fprintf(mul,"\n");
			n++;
		}
		if (j==xray) xray = -nseq;
		fprintf(mul,"*\n");
		nseq++;
	}
	xray = -xray;
	fclose(mul);
	out = fopen("select.out","w");
	fprintf(out,"Block %d = xray\n", xray);
	fprintf(out,"%d\n", nseq);
	for (i=0; i<nseq; i++) fprintf(out,"%s %s\n", seq[i].code,seq[i].title);
	n = 0;
	for (i=0; i<length; i++)
	{ int	res = 0;
		for (j=0; j<nseq; j++) if (seq[j].residue[i] != '-') res++;
		if (!res) continue;
		for (j=0; j<nseq; j++) {
			fprintf(out,"%c", seq[j].residue[i]);
			seq[j].residue[n] = seq[j].residue[i];
		}
		fprintf(out,"\n");
		n++;
	}
	fclose(out);
	length = n;
	return nseq;
}

combine (seq,nseq,pred,vari,phob,dssp,cone)
Seqs	*seq;
int	nseq;
float	*pred, *vari, *phob, *dssp, *cone;
{
	int	i, j, n, last;
	FILE	*out;
	out = fopen("combine.out","w");
	fprintf(out,"Seq %d = xray\n", xray+1);
	fprintf(out,"%d\n", nseq);
	n = 0;
	for (i=0; i<nseq; i++) fprintf(out,"%s %s\n", seq[i].code,seq[i].title);
	last = -1;
	for (i=0; i<length; i++)
	{ int	memb = 0, gaps = 0;
	  float pct;
	  char	a = ' ', b = ' ', c = ' ';
		if (seq[xray].residue[i] == '-') continue;
		n++;
		for (j=0; j<nseq; j++) {
			if (isupper(seq[j].residue[i])) memb++;
			if (seq[j].residue[i]=='-') gaps++;
		}
		if (isupper(seq[xray].residue[i])) memb += 1;
		pct = 100.0*(float)memb/(float)(nseq-gaps);
		if (pct<5.0 && seg[n]==0 && top[n]==0) continue;
		if (last+1 != i) fprintf(out,"       :\n");
		last = i;
		if (seg[n]) a = '|';
		if (top[n]) b = 't';
		if (top[n]>5) b = 'T';
		if (pct>30.0) c = 'm';
		if (pct>30.0 && isupper(seq[xray].residue[i])) c = 'M';
		if (pct>50.0) c = 'M';
		fprintf(out,"%c%c%c%5d%5d ", a,b,c,n,i+1);
		for (j=0; j<nseq; j++) fprintf(out,"%c", seq[j].residue[i]);
/*
		if (seq[xray].residue[i] == '-') { int k;
			for (k=0; k<5; k++) fprintf(out,"     .   ");
			fprintf(out,"\n");
			continue;
		}
*/
		fprintf(out,"%9.3f%9.3f%9.3f%9.3f%9.3f\n",
			pred[i],vari[i],phob[i],dssp[i],cone[i]);
	}
	fclose(out);
}

profile (seq,memb,xvari,xphob)
Seqs	*seq;
int	memb;
float	*xvari, *xphob;
{
	float	vari[NRES], phob[NRES], fcons, phobs;
	int	i, j, k, n, pairs, cons;
	n = 0;
	for (i=0; i<length; i++) {
		pairs = cons = 0;
		for (j=0; j<memb-1; j++)
		{ char	jres = seq[j].residue[i];
		  char	Jres = UPPER(jres);
			for (k=j; k<memb; k++)
			{ char	kres = seq[k].residue[i];
			  char	Kres = UPPER(kres);
				pairs++;
				if (jres == '-') cons -= GAPEN;
				if (kres == '-') cons -= GAPEN;
				if((jres == '-') && (kres == '-')) continue;
				cons += id_mat[Jres-'A'][Kres-'A'];
			}
		}
		xvari[i] = vari[i] = fcons = (float)cons/(float)pairs;
		phobs = 0.0;
		for (j=0; j<memb; j++)
		{ char	r = seq[j].residue[i];
			if (r=='-') continue;
			phobs += phobic[UPPER(r)-'A'];
		}
		xphob[i] = phob[i] = phobs = phobs/(float)memb;
/*
		if (seq[xray].residue[i] == '-') continue;
		xvari[n] = fcons;
		xphob[n] = phobs;
*/
		n++;
	}
	return n;
}

norm (cut, data, n) float cut, *data; int n; {
float	d, fn, sigcut,
	ave, var, sig;
int	i, j, k, mods;
	fn = (float)n;
	ave = 0.0;
	for (i=0; i<n; i++) ave += data[i];
	ave /= fn;
	var = 0.0;
	for (i=0; i<n; i++) {
		data[i] -= ave;
		var += data[i]*data[i];
	}
	var /= fn;
	sig = sqrt(var);
	mods = 0;
	sigcut = sig*cut;
	for (i=0; i<n; i++) {
		data[i] /= sig;
		if (data[i] > sigcut) {
			data[i] =  sigcut + 0.5*(data[i]-sigcut);
			mods++;
		}
		if (data[i] <-sigcut) {
			data[i] = -sigcut + 0.5*(data[i]+sigcut);
			mods++;
		}
	}
	return mods;
}

phobin (file) char *file;
{
	int	i;
	FILE	*pho;
	pho = fopen(file,"r");
	for (i=0; i<NACID; i++) phobic[i] = 0.0;
	while (!feof(pho)) { char a; float phob;
		next_line(pho);
		fscanf(pho,"%c %f", &a, &phob);
		phobic[a-'A'] = phob;
	}
}
